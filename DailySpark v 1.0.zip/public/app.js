document.addEventListener('DOMContentLoaded', () => {
    const quoteTextEl = document.getElementById('quote-text');
    const quoteAuthorEl = document.getElementById('quote-author');
    const quizQuestionEl = document.getElementById('quiz-question');
    const quizOptionsEl = document.getElementById('quiz-options');
    const quizResultEl = document.getElementById('quiz-result');
    const quizExplanationEl = document.getElementById('quiz-explanation');

    const currentDateEl = document.getElementById('current-date');
    const prevDayBtn = document.getElementById('prev-day-btn');
    const nextDayBtn = document.getElementById('next-day-btn');

    const shareWhatsappBtn = document.getElementById('share-whatsapp');
    const shareFacebookBtn = document.getElementById('share-facebook');
    const shareCopyBtn = document.getElementById('share-copy');

    let currentQuote = '';
    let currentQuizAnswerIndex = -1;
    let currentDate = new Date();

    /**
     * Fetches and displays daily content for a given date.
     * @param {string} dateString - The date in YYYY-MM-DD format.
     */
    const fetchDailyContent = async (dateString) => {
        try {
            const response = await fetch(`/api/daily?date=${dateString}`);
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            
            displayContent(data);
        } catch (error) {
            console.error('Failed to fetch daily content:', error);
            quoteTextEl.textContent = 'Could not load content. Please try again later.';
        }
    };

    /**
     * Renders the fetched content onto the page.
     * @param {object} data - The data object from the API.
     */
    const displayContent = (data) => {
        // --- Display Quote ---
        currentQuote = `"${data.quote.text}" - ${data.quote.author}`;
        quoteTextEl.textContent = `"${data.quote.text}"`;
        quoteAuthorEl.textContent = `– ${data.quote.author}`;

        // --- Display Quiz ---
        currentQuizAnswerIndex = data.quiz.correctAnswer;
        quizQuestionEl.textContent = data.quiz.question;
        quizOptionsEl.innerHTML = '';
        data.quiz.options.forEach((option, index) => {
            const button = document.createElement('button');
            button.className = 'quiz-option';
            button.textContent = option;
            button.dataset.index = index;
            button.addEventListener('click', handleQuizAnswer);
            quizOptionsEl.appendChild(button);
        });
        
        quizResultEl.style.display = 'none';
        quizExplanationEl.textContent = data.quiz.explanation;

        // --- Update Date Display ---
        const displayDate = new Date(data.date + 'T00:00:00Z');
        currentDateEl.textContent = displayDate.toLocaleDateString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC'
        });

        // Enable/disable next button if it's today
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0);
        nextDayBtn.disabled = displayDate >= today;
    };
    
    /**
     * Handles the user clicking on a quiz option.
     * @param {Event} event - The click event.
     */
    const handleQuizAnswer = (event) => {
        const selectedOption = event.target;
        const selectedAnswer = parseInt(selectedOption.dataset.index);

        if (selectedAnswer === currentQuizAnswerIndex) {
            selectedOption.classList.add('correct');
        } else {
            selectedOption.classList.add('incorrect');
            // Also show the correct answer
            const correctOption = quizOptionsEl.querySelector(`[data-index='${currentQuizAnswerIndex}']`);
            correctOption.classList.add('correct');
        }

        // Disable all buttons and show explanation
        quizOptionsEl.querySelectorAll('.quiz-option').forEach(btn => btn.disabled = true);
        quizResultEl.style.display = 'block';
    };

    /**
     * Handles date navigation.
     * @param {number} dayOffset - The number of days to move (-1 for previous, 1 for next).
     */
    const navigateDays = (dayOffset) => {
        currentDate.setUTCDate(currentDate.getUTCDate() + dayOffset);
        const dateString = currentDate.toISOString().split('T')[0];
        fetchDailyContent(dateString);
    };

    // --- Event Listeners ---
    prevDayBtn.addEventListener('click', () => navigateDays(-1));
    nextDayBtn.addEventListener('click', () => navigateDays(1));

    shareWhatsappBtn.addEventListener('click', () => {
        const text = `Today's inspiration from DailySpark:\n\n${currentQuote}\n\nCheck it out: ${window.location.href}`;
        const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
        window.open(whatsappUrl, '_blank');
    });

    shareFacebookBtn.addEventListener('click', () => {
        const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(currentQuote)}`;
        window.open(facebookUrl, '_blank');
    });

    shareCopyBtn.addEventListener('click', () => {
        const textToCopy = `Today's inspiration from DailySpark:\n${currentQuote}\n\n${window.location.href}`;
        navigator.clipboard.writeText(textToCopy).then(() => {
            shareCopyBtn.textContent = 'Copied!';
            setTimeout(() => {
                shareCopyBtn.innerHTML = '<img src="/icons/copy.svg" alt="Copy Link"> Copy Link';
            }, 2000);
        });
    });

    // --- Initial Load ---
    const initialDateString = new Date().toISOString().split('T')[0];
    fetchDailyContent(initialDateString);
});