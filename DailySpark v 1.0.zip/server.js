// Load environment variables from .env file
require('dotenv').config();
const express = require('express');
const fs = a= require('fs').promises;
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Middleware ---
app.use(helmet()); // For basic security headers
app.use(cors());   // To allow frontend requests
app.use(express.json()); // To parse JSON bodies
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files from 'public' folder
app.use('/admin', express.static(path.join(__dirname, 'admin'))); // Serve admin static files

// --- File Paths ---
const QUOTES_PATH = path.join(__dirname, 'data', 'quotes.json');
const QUIZZES_PATH = path.join(__dirname, 'data', 'quizzes.json');
const STATS_PATH = path.join(__dirname, 'data', 'stats.json');

// --- Helper Functions ---

/**
 * Reads and parses a JSON file safely.
 * @param {string} filePath - The path to the JSON file.
 * @returns {Promise<object>} The parsed JSON data.
 */
const readJsonFile = async (filePath) => {
    try {
        const data = await fs.readFile(filePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading or parsing ${filePath}:`, error);
        throw new Error('Could not read data file.');
    }
};

/**
 * Writes data to a JSON file atomically.
 * @param {string} filePath - The path to the JSON file.
 * @param {object} data - The data to write.
 */
const writeJsonFile = async (filePath, data) => {
    try {
        await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
        console.error(`Error writing to ${filePath}:`, error);
        throw new Error('Could not write data file.');
    }
};

/**
 * Calculates the number of days since the Unix epoch (1970-01-01).
 * @param {Date} date - The date to calculate from.
 * @returns {number} The number of full days passed.
 */
const getDayIndex = (date) => {
    const epoch = new Date('1970-01-01T00:00:00Z');
    const diff = date.getTime() - epoch.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
};

/**
 * Middleware to track hits on endpoints.
 * @param {string} endpointName - The name of the endpoint to track.
 */
const trackHit = (endpointName) => async (req, res, next) => {
    try {
        const stats = await readJsonFile(STATS_PATH);
        stats.hits[endpointName] = (stats.hits[endpointName] || 0) + 1;
        await writeJsonFile(STATS_PATH, stats);
    } catch (error) {
        console.error('Failed to track hit:', error);
    }
    next();
};

// --- Admin Authentication Middleware ---

/**
 * Verifies the admin token from the x-admin-token header.
 */
const verifyAdminToken = async (req, res, next) => {
    const token = req.headers['x-admin-token'];
    if (!token) {
        return res.status(401).json({ message: 'Unauthorized: No token provided.' });
    }
    try {
        const stats = await readJsonFile(STATS_PATH);
        if (stats.adminTokens && stats.adminTokens.includes(token)) {
            next(); // Token is valid
        } else {
            res.status(403).json({ message: 'Forbidden: Invalid token.' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server error during authentication.' });
    }
};


// --- API Endpoints ---

// GET /api/daily - Get the quote and quiz for a specific day (or today)
app.get('/api/daily', trackHit('daily'), async (req, res) => {
    try {
        const { date } = req.query;
        // Use provided date or current UTC date
        const targetDate = date ? new Date(date + 'T00:00:00Z') : new Date();
        if (isNaN(targetDate.getTime())) {
            return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD." });
        }
        
        const dayIndex = getDayIndex(targetDate);

        const [quotes, quizzes] = await Promise.all([
            readJsonFile(QUOTES_PATH),
            readJsonFile(QUIZZES_PATH),
        ]);

        const quote = quotes[dayIndex % quotes.length];
        const quiz = quizzes[dayIndex % quizzes.length];

        res.json({
            date: targetDate.toISOString().split('T')[0],
            quote,
            quiz,
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch daily content.' });
    }
});

// GET /api/quotes - Get all quotes
app.get('/api/quotes', trackHit('get_quotes'), async (req, res) => {
    res.sendFile(QUOTES_PATH);
});

// GET /api/quizzes - Get all quizzes
app.get('/api/quizzes', trackHit('get_quizzes'), async (req, res) => {
    res.sendFile(QUIZZES_PATH);
});

// --- Admin Endpoints ---

// POST /api/admin/login - Admin login
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    const { ADMIN_USER, ADMIN_PASS } = process.env;

    if (username === ADMIN_USER && password === ADMIN_PASS) {
        try {
            const token = crypto.randomBytes(24).toString('hex');
            const stats = await readJsonFile(STATS_PATH);
            stats.adminTokens = stats.adminTokens || [];
            // For simplicity, we can just use one token at a time or allow multiple
            // To keep it simple, we'll just store the latest one.
            stats.adminTokens = [token]; // Or push to allow multiple sessions
            await writeJsonFile(STATS_PATH, stats);
            res.json({ token });
        } catch (error) {
            res.status(500).json({ message: 'Server error during login.' });
        }
    } else {
        res.status(401).json({ message: 'Invalid credentials.' });
    }
});

// GET /api/stats - Get hit statistics (admin only)
app.get('/api/stats', verifyAdminToken, async (req, res) => {
    res.sendFile(STATS_PATH);
});

// POST /api/quotes - Add a new quote (admin only)
app.post('/api/quotes', verifyAdminToken, async (req, res) => {
    const { text, author, type } = req.body;
    if (!text || !author) {
        return res.status(400).json({ message: 'Text and author are required.' });
    }
    
    try {
        const quotes = await readJsonFile(QUOTES_PATH);
        const newQuote = {
            id: quotes.length > 0 ? Math.max(...quotes.map(q => q.id)) + 1 : 1,
            text,
            author,
            type: type || 'Universal'
        };
        quotes.push(newQuote);
        await writeJsonFile(QUOTES_PATH, quotes);
        res.status(201).json(newQuote);
    } catch (error) {
        res.status(500).json({ message: 'Failed to add quote.' });
    }
});

// POST /api/quizzes - Add a new quiz (admin only)
app.post('/api/quizzes', verifyAdminToken, async (req, res) => {
    const { question, options, correctAnswer, explanation } = req.body;
    if (!question || !options || correctAnswer === undefined) {
        return res.status(400).json({ message: 'Question, options, and correctAnswer are required.' });
    }

    try {
        const quizzes = await readJsonFile(QUIZZES_PATH);
        const newQuiz = {
            id: quizzes.length > 0 ? Math.max(...quizzes.map(q => q.id)) + 1 : 1,
            question,
            options,
            correctAnswer,
            explanation
        };
        quizzes.push(newQuiz);
        await writeJsonFile(QUIZZES_PATH, quizzes);
        res.status(201).json(newQuiz);
    } catch (error) {
        res.status(500).json({ message: 'Failed to add quiz.' });
    }
});


// --- Serve root frontend file ---
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Start Server ---
app.listen(PORT, () => {
    console.log(`✨ DailySpark server running on http://localhost:${PORT}`);
});