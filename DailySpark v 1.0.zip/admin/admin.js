document.addEventListener('DOMContentLoaded', () => {
    const loginSection = document.getElementById('login-section');
    const dashboardSection = document.getElementById('dashboard-section');
    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');
    const logoutBtn = document.getElementById('logout-btn');

    const addQuoteForm = document.getElementById('add-quote-form');
    const quotesList = document.getElementById('quotes-list');

    const API_BASE_URL = '/api';
    let adminToken = localStorage.getItem('adminToken');

    /**
     * Toggles between the login view and the dashboard view.
     */
    const checkLoginState = () => {
        if (adminToken) {
            loginSection.classList.add('hidden');
            dashboardSection.classList.remove('hidden');
            loadQuotes();
        } else {
            loginSection.classList.remove('hidden');
            dashboardSection.classList.add('hidden');
        }
    };

    /**
     * Handles the login form submission.
     */
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        loginError.textContent = '';
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch(`${API_BASE_URL}/admin/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                adminToken = data.token;
                localStorage.setItem('adminToken', adminToken);
                checkLoginState();
            } else {
                loginError.textContent = data.message || 'Login failed.';
            }
        } catch (error) {
            loginError.textContent = 'An error occurred. Please try again.';
        }
    });

    /**
     * Handles logout.
     */
    logoutBtn.addEventListener('click', () => {
        adminToken = null;
        localStorage.removeItem('adminToken');
        checkLoginState();
    });

    /**
     * Fetches and displays all quotes.
     */
    const loadQuotes = async () => {
        if (!adminToken) return;

        try {
            const response = await fetch(`${API_BASE_URL}/quotes`, {
                headers: { 'x-admin-token': adminToken }
            });
            const quotes = await response.json();
            quotesList.innerHTML = ''; // Clear list
            quotes.reverse().forEach(quote => {
                const div = document.createElement('div');
                div.className = 'item';
                div.innerHTML = `
                    <p>"${quote.text}"</p>
                    <small>– ${quote.author} [${quote.type}]</small>
                `;
                quotesList.appendChild(div);
            });
        } catch (error) {
            quotesList.innerHTML = '<p class="error-message">Could not load quotes.</p>';
        }
    };
    
    /**
     * Handles the form submission for adding a new quote.
     */
    addQuoteForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = document.getElementById('quote-text').value;
        const author = document.getElementById('quote-author').value;
        const type = document.getElementById('quote-type').value;

        try {
            const response = await fetch(`${API_BASE_URL}/quotes`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-admin-token': adminToken
                },
                body: JSON.stringify({ text, author, type })
            });

            if (response.ok) {
                addQuoteForm.reset();
                loadQuotes(); // Refresh the list
            } else {
                const err = await response.json();
                alert(`Error: ${err.message}`);
            }
        } catch (error) {
            alert('An error occurred while adding the quote.');
        }
    });

    // Initial check on page load
    checkLoginState();
});